char * createLog();
int openLog(char *logFilename);
void closeLog(int logFile);