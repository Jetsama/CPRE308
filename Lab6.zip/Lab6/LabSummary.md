Lab 6\
Jonathan Hess\
In this lab I implemented the 3 algorithms. I implemented the OPT with a for loop for all the frames then a while loop to check when that frame got accessed again. The OPT could be optimized more by reversing the order of the loops. I didn't feel the need because it runs in a short enough time and is a non-realistic algorithm. Learning debugging from the previous projects helped a lot as seeing the structure at breakpoints helped solve small errors. Overall a good introduction to page memory management algorithms.
